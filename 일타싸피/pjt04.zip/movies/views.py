from textwrap import indent
from urllib import response
from django.shortcuts import render
import requests
import random
import json

# Create your views here.
def choice(request):
    BASE = 'https://api.themoviedb.org/3'
    path = '/movie/top_rated'
    params = {
        'api_key' : '599d9943faf8858722e82a75833aa6b0',
        'region' : 'KR'
    }
    response = requests.get(BASE+path,params=params)
    data = response.json()
    # 포스터, 제목, 줄거리 , 개봉일자
    # poster_path , title, overview , release_date
    movies = data.get('results')
    poster = []
    title = []
    overview = []
    relase = []
    for m in movies:
        poster.append(m.get('poster_path'))
        title.append(m.get('title'))
        overview.append(m.get('overview'))
        relase.append(m.get('release_date'))
    
    context = dict(
        poster = poster,
        title = title,
        overview = overview,
        relase = relase,
    )

    print(poster[0])
    return render(request,'movies/choice.html',context)

def index(request):
    return render(request,'movies/index.html')


def recommendations(request):
    BASE = 'https://api.themoviedb.org/3'
    path = '/search/movie'
    params = {
        'api_key' : '599d9943faf8858722e82a75833aa6b0',
        'query' : '쇼생크 탈출',
        'region' : 'KR',
        'language' : 'ko'
    }
    response = requests.get(BASE+path,params=params)
    data = response.json()
    
    # print(json.dumps(data,indent="\t"))

    movie = data.get('results')
    for m in movie:
        movie_id = m.get('id')

    # print(movie_id) -> 278

    ######################################################
    BASE = 'https://api.themoviedb.org/3'
    path = '/movie/'+str(movie_id)+'/recommendations'
    params = {
        'api_key' : '599d9943faf8858722e82a75833aa6b0',
        'region' : 'KR',
        'language' : 'ko',
    }
    
    response2 = requests.get(BASE+path,params=params)
    data2 = response2.json() # data 2 에 쇼생크 탈출 추천 영화들이 저장돼요
    # print(json.dumps(data2,indent="\t").encode('UTF-8'))
    '''
    이제 data2 안 정보들 중에서 랜덤으로 하나 선택한다음에
    선택 된거의 포스터 , 영화 제목, 평점 , 상세 정보 
    이거를 recomendation.html 에 출력하면 될거 같아요!

    poster_path , vote_average,title,overview
    '''
    movies2 = data2.get('results')
    pick = random.choice(movies2)
    title = pick.get('title')
    overview = pick.get('overview')
    vote_average = round(float(pick.get('vote_average')),1)
    poster_path = pick.get('poster_path')
    release_date = pick.get('release_date')
    pick_id = pick.get('id')

    context = dict(
        title = title,
        overview = overview,
        vote_average = vote_average,
        poster_path = poster_path,
        release_date = release_date,
        pick_id = pick_id,
    )
    return render(request, 'movies/recommendations.html',context)
